<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Emoji',
	'description' => '',
	'version'     => '1.0.0',
	'namespace'   => 'EllisLab\Addons\Emoji',
	'settings_exist' => FALSE,
);
