<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'HTTP Header',
	'description'    => 'Set HTTP Headers in your templates',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\HTTPHeader',
	'settings_exist' => FALSE,
	'built_in'       => FALSE,
);
