<?php
/**
 * ExpressionEngine (https://expressionengine.com)
 *
 * @link      https://expressionengine.com/
 * @copyright Copyright (c) 2003-2018, EllisLab, Inc. (https://ellislab.com)
 * @license   https://expressionengine.com/license
 */

/**
 * File Module control panel
 */
class File_mcp {

	var $stats_cache	= array(); // Used by mod.stats.php

}
// END CLASS

// EOF
