<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'RSS Parser',
	'description' => 'Retrieves and Parses RSS/Atom Feeds',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\RssParser',
	'settings_exist' => FALSE
);

// EOF
