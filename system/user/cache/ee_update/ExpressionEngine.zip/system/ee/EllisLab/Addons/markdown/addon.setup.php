<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Markdown',
	'description' => 'Parse text using Markdown and Smartypants',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\Markdown',
	'settings_exist' => FALSE,
	'plugin.typography' => TRUE
);

// EOF
